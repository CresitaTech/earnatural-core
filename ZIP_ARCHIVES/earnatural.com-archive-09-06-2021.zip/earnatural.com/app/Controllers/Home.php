<?php

namespace App\Controllers;


class Home extends BaseController
{
	public function index()
	{
		return view('site');
	}

	function sendMail() { 
        $to = 'naresh.khuriwal89@gmail.com';
        $subject = 'Final Agent Mail';
        $message = 'This is testing email from ';
        
        $email = \Config\Services::email();

        $email->setTo($to);
        $email->setFrom('admin@earnatural.com', 'Confirm Registration');
        $data = array();
        $email->setSubject($subject);
        $email->setMessage(view('templates/orderInternalMail', $data ));

        if ($email->send()) 
		{
            echo 'Email successfully sent';
        } 
		else 
		{
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }
    }

}
