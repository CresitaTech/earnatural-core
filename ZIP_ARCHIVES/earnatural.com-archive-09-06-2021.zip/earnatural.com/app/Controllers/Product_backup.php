<?php
namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\HTTP\RequestInterface;
use App\Models\User;
use App\Models\Order;
use App\Libraries; 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Luhn;

class Product extends ResourceController {
	
    protected $modelName = 'App\Models\Product';
    protected $format    = 'json';
	// fetch all products
    public function index() {
        return $this->respond($this->model->findAll());
    }

    // save new product info
    public function create() {
		// get posted JSON
		//$json = json_decode(file_get_contents("php://input", true));
		$json = $this->request->getJSON();
        $items = array();
        $data = array(
            'itemId' => rand(00000000,999999999),
            'name' => 'Ear Natural ® ear drops',
            'description' => "Truly a miraculous OTC medicine for ear-infections, so common among children.",
            'quantity' => $json->quantity,
            'unitPrice' => $json->unitPrice,
            'subtotal' => $json->quantity * $json->unitPrice
        );
        array_push($items, $data);

        $user = new User();
        $userdata = array(
            'card_holder_name' => $json->card_holder_name,
			'email' => $json->email,
            'address_1' => $json->address_1,
            'address_2' => $json->address_2,
            'city' => $json->city,
            'state' => $json->state,
            'zip' => $json->zip,
            'shipping_address_1' => $json->optradio == 'Same' ? $json->address_1 : $json->shipping_address_1,
            'shipping_address_2' => $json->optradio == 'Same' ? $json->address_2 : $json->shipping_address_2,
            'shipping_city' => $json->optradio == 'Same' ? $json->city : $json->shipping_city,
            'shipping_state' => $json->optradio == 'Same' ? $json->state : $json->shipping_state,
            'shipping_zip' => $json->optradio == 'Same' ? $json->zip : $json->shipping_zip,
            'created_at' => date('Y-m-d H:i:s')
        );
        $customer_id = $user->insert($userdata);
        $expDataArr = explode("/", $json->expiryDate);
        $data = array(
            'customer_id' => $customer_id,
            'card_number' => $json->cardNumber1.$json->cardNumber2.$json->cardNumber3.$json->cardNumber4,
            'expiration_date' => trim($expDataArr[1]).'-'.trim($expDataArr[0]),
            'cvv' =>  $json->cvv,
            'card_holder_name' => $json->card_holder_name,
			'email' => $json->email,
            'address_1' => $json->address_1,
            'address_2' => $json->address_2,
            'city' => $json->city,
            'state' => $json->state,
            'zip' => $json->zip,
            'shipping_address_1' => $json->optradio == 'Same' ? $json->address_1 : $json->shipping_address_1,
            'shipping_address_2' => $json->optradio == 'Same' ? $json->address_2 : $json->shipping_address_2,
            'shipping_city' => $json->optradio == 'Same' ? $json->city : $json->shipping_city,
            'shipping_state' => $json->optradio == 'Same' ? $json->state : $json->shipping_state,
            'shipping_zip' => $json->optradio == 'Same' ? $json->zip : $json->shipping_zip,
            'created_at' => date('Y-m-d H:i:s')
        );
		
        $response = $this->procced_credit_card_payment_checkout($user, $data, $items);
		return $this->respondCreated($response);
    }

    
    function procced_credit_card_payment_checkout($user, $postdata, $items)
    {
        $order = new Order();
        $request = $user->get_post_data($items, $postdata);
        $result =  $user->post_json($request);
        $response = str_replace('?', '', utf8_decode($result));
        $object = json_decode($response);
        $resMsg = "No response returned";
        // Check to see if the API request was successfully received
        if($object->messages->resultCode == 'Ok' ){ 
            // Since the API request was successful, look for a transaction response
            if($object->transactionResponse->responseCode == '1'){
                $transaction = $object->transactionResponse;
                $orderData = array(
                    'refId' => $object->refId,
                    'accountNumber' => $transaction->accountNumber,
                    'accountType' => $transaction->accountType,
                    'authCode' => $transaction->authCode,
                    'avsResultCode' => $transaction->avsResultCode,
                    'cavvResultCode' => $transaction->cavvResultCode,
                    'cvvResultCode' => $transaction->cvvResultCode,
                    'refTransID' => $transaction->refTransID,
                    'responseCode' => $transaction->responseCode,
                    'transId' => $transaction->transId,
                    'customerId' => $transaction->userFields[0]->value,
                    'status' => $object->messages->resultCode,
                    'createdAt' => date('Y-m-d H:i:s')
                );
                $resMsg = $transaction->messages[0]->description;
                $order->insert($orderData);
                $this->sendMailToCustomer($postdata, $items);
                return $this->get_response(201, $resMsg);
            }else{
                $transaction = $object->transactionResponse;
                $resMsg = $transaction->errors[0]->errorText;
                return $this->get_response(400, $resMsg);
            }
            
        }else{
            // Or, print errors if the API request wasn't successful
            $resMsg = $object->messages->message[0]->text;
            if($resMsg != ""){
                return $this->get_response(400, $resMsg);
            }else{
                $transaction = $object->transactionResponse;
                $resMsg = $transaction->errors[0]->errorText;
                return $this->get_response(400, $resMsg);
            }
            
        }
        
        return $this->get_response(400, $resMsg);

    }

    function get_response($code, $message){
        $response = array(
            'status'   => $code,
            'messages' => array(
                'success' => $message
            )
        );
        return $response;
    }
    
	function sendMailToCustomer($postData, $items){
		$data['orderData'] = array(
			'postData' => $postData,
			'cartItem' => $items
		);
		
        $email = \Config\Services::email();
        //$email->setTo("agrawalv@cresitatech.com");
        $email->setCC('kuriwaln@opallios.com ');
		$email->setTo($postData['email']); 
        #$email->setTo('sales@ipgnaturalhealth-retail.com');
        $email->setFrom('support@earnatural.com', 'Earnatural Team');
        $email->setSubject("Your earnatural.com order #".$postData['customer_id']);
        $email->setMessage(view('templates/orderMail', $data ));		
        if (!$email->send()) 
		{
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }


        $email->setTo("kuriwaln@opallios.com");
        $email->setCC('kuriwaln@opallios.com');

        #$email->setTo('sales@ipgnaturalhealth-retail.com');
        $email->setFrom('support@earnatural.com', 'Earnatural Team');
        $email->setSubject("Order Confirmation #".$postData['customer_id']);
        $email->setMessage(view('templates/orderInternalMail', $data ));
        if (!$email->send()) 
		{
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }


	}

    
	function validateCard($vnumber)
	{
	    require APPPATH.'Libraries/Luhn.php';
	    $luhn = new Luhn();
	    if ($luhn->validate(substr($vnumber, 0, -1), substr($vnumber, -1, 1)) == true) {
	        $vresult = "VALID";
	    } else {
	        $vresult = "INVALID";
	    }
	    echo json_encode(array('status' => $vresult));
	    
	}


    
}