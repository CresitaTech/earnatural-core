<?php
namespace App\Models;
use CodeIgniter\Model;

class User extends Model {

	protected $table      = 'users';
    protected $primaryKey = 'id';
	
	protected $returnType     = 'array';

    protected $allowedFields = [
        'card_holder_name', 
        'phone_number', 
        'email', 
        'address_1',
        'address_2',
        'city',
        'state',
        'zip',
        'shipping_address_1',
        'shipping_address_2',
        'shipping_city',
        'shipping_state',
        'shipping_zip',
        'created_at'
    ];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

    //private $baseUrl = 'https://apitest.authorize.net/xml/v1/request.api';
    private $baseUrl = 'https://api.authorize.net/xml/v1/request.api';
    
    function post_json($data){
        $data_string = json_encode($data);
        $ch=curl_init($this->baseUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $response = curl_exec( $ch );
        /**if(!$response){
            die('Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
        } */
        curl_close($ch);
        return $response;
    }
    
    
    function get_post_data($cart, $postdata){
        $grand_total = 0;
        $items = array();
       
        foreach ($cart as $item){
            $data = array(
                'itemId' => $item['itemId'],
                'name' => $item['name'],
                'description' => $item['description'],
                'quantity' => $item['quantity'],
                'unitPrice' => $item['unitPrice'],
            );
            $grand_total = $grand_total + $item['subtotal'];
            array_push($items, $data);
        }

        $grand_total = $grand_total + $item['subtotal'];
        array_push($items, $data);
        
        $payment = array ('creditCard' => array (
            'cardNumber' => $postdata['card_number'],
            'expirationDate' => $postdata['expiration_date'],
            'cardCode' => $postdata['cvv'],
                ),
        );
        
        $lineItems = array ('lineItem' => $items );
        $postData = array (
            'createTransactionRequest' => array (
                'merchantAuthentication' => array (
                    'name' => '9U5u46THeuL',
                    'transactionKey' => '8mu3y8D595Lh6nPW',
                    #'name' => '5KP3u95bQpv',
                    #'transactionKey' => '346HZ32z3fP4hTG2',
                ),
                'refId' => date('His').$postdata['customer_id'],
                'transactionRequest' => array (
                    'transactionType' => 'authCaptureTransaction',
                    'amount' => $grand_total,
                    'payment' => $payment,
                    'lineItems' => $lineItems,
                    'customer' => array (
                        'id' => $postdata['customer_id'],
                    ),
                    'billTo' => array (
                        'firstName' => $postdata['card_holder_name'],
                        'lastName' => "",//$postdata['last_name']
                        'company' => '',
                        'address' => $postdata['address_1'] . ' ' . $postdata['address_1'],
                        'city' => $postdata['city'],
                        'state' => $postdata['state'],
                        'zip' => $postdata['zip'],
                        'country' => '',
                    ),
                    'shipTo' => array (
                        'firstName' => $postdata['card_holder_name'],
                        'lastName' => "",//$postdata['shipping_last_name']
                        'company' => '',
                        'address' => $postdata['shipping_address_1'] . ' ' . $postdata['shipping_address_2'],
                        'city' => $postdata['shipping_city'],
                        'state' => $postdata['shipping_state'],
                        'zip' => $postdata['shipping_zip'],
                        'country' => "",
                    ),
                    'customerIP' => $_SERVER['REMOTE_ADDR'],
                    'userFields' => array (
                        'userField' => array (
                            0 => array (
                                'name' => 'customer_id',
                                'value' => $postdata['customer_id'],
                            ),
                        ),
                    ),
                    "processingOptions" => array(
                        "isSubsequentAuth" => "true"
                    ),
                    "subsequentAuthInformation" => array(
                        "originalNetworkTransId" => "123456789NNNH",
                        "originalAuthAmount" => "45.00",
                        "reason" => "resubmission"         
                    ),			
                    "authorizationIndicatorType" => array(
                       "authorizationIndicator" => "final"
                    )
                ),
            ),
        );
        
        return $postData;
    }


}
