<?php
namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\HTTP\RequestInterface;
use App\Models\Customer;
use App\Models\Product as ProductModel;
use App\Models\Order;
use App\Libraries; 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use App\Libraries\Utils; // Import library
use App\Libraries\Luhn; // Import library

class Product extends ResourceController {
	
    protected $modelName = 'App\Models\ProductModel';
    protected $format    = 'json';
	// fetch all products
    public function index() {
        return $this->respond($this->model->findAll());
    }

    // save new product info
    public function create() {
		// get posted JSON
		//$json = json_decode(file_get_contents("php://input", true));
		$json = $this->request->getJSON();
        $product = new ProductModel();
        $customer = new Customer();
        $common = new Utils();

        $items = $common->get_product($json);
        $userdata = $common->get_customer_info($json);
        $customer_id = $customer->insert($userdata);
        $postdata = $common->get_post_request($json, $customer_id);

        $response = $this->procced_credit_card_payment_checkout($common, $postdata, $items);
		return $this->respondCreated($response);
    }

    
    function procced_credit_card_payment_checkout($common, $postdata, $items)
    {
        $order = new Order();
        $request = $common->get_post_data($items, $postdata);
        $result =  $common->post_json($request);
        $response = str_replace('?', '', utf8_decode($result));
        $response = json_decode($response);
        $resMsg = ERROR_500;
        // Check to see if the API request was successfully received
        try
        {
            log_message('info', RESPONSE, $this->set_error(200, json_encode($response)) );
            if($response->messages->resultCode == 'Ok' ){ 
                // Since the API request was successful, look for a transaction response
                // and parse it to display the results of authorizing the card
                $tresponse = $response->transactionResponse;
                if ($tresponse != null && $tresponse->messages != null) {
                    
                    $orderData = $product->get_order_info($response);

                    $resMsg = $tresponse->messages[0]->description;
                    $order->insert($orderData);
                    $this->sendMailToCustomer($postdata, $items);
                    log_message('info', SUCCESS_INFO, $this->set_error($tresponse->messages[0]->code,
                    $tresponse->messages[0]->description));

                    return $this->get_response(201, $resMsg);
                } else {
                    if ($tresponse->errors != null) {
                        log_message('info', ERROR_INFO, $this->set_error($tresponse->errors[0]->errorCode,
                        $tresponse->errors[0]->errorText));
                        $resMsg = $tresponse->errors[0]->errorText;
                        return $this->get_response(400, $resMsg);
                    }                
    
                }

            }else{
                    $tresponse = $response->transactionResponse;
                if ($tresponse != null && $tresponse->errors != null) {
                    log_message('info', ERROR_INFO, $this->set_error($tresponse->errors[0]->errorCode,
                    $tresponse->errors[0]->errorText));
                    $resMsg = $tresponse->errors[0]->errorText;
                    return $this->get_response(400, $resMsg);
                } else {
                    log_message('info', ERROR_INFO, $this->set_error($response->messages->message[0]->code,
                    $response->messages->message[0]->text));
                    $resMsg = $object->messages->message[0]->text;
                    return $this->get_response(400, $resMsg);
                }
    
            }
            
        }
        catch (\Exception $e)
        {
            log_message('error', '[ERROR] {exception}', ['exception' => $e]);
            return $this->get_response(400, $resMsg);

        }
        
    }

    function get_response($code, $message){
        $response = array(
            'status'   => $code,
            'messages' => array(
                'success' => $message
            )
        );
        return $response;
    }

    function set_error($code, $message){
        $response = array(
            'code'   => $code,
            'message' => $message
        );
        return $response;
    }
    
	function sendMailToCustomer($postData, $items){
		$data['orderData'] = array(
			'postData' => $postData,
			'cartItem' => $items
		);
		
        $email = \Config\Services::email();
        //$email->setTo("agrawalv@cresitatech.com");
        //$email->setCC('kuriwaln@opallios.com ');
		$email->setTo($postData['email']); 
        #$email->setTo('sales@ipgnaturalhealth-retail.com');
        $email->setFrom('support@earnatural.com', 'Earnatural Team');
        //$email->setSubject("Your earnatural.com order #".$postData['customer_id']);
		$email->setSubject("Order/Inquiry @ Earnatural.com");
        $email->setMessage(view('templates/orderMail', $data ));		
        if (!$email->send()) 
		{
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }
		
        $email->setTo("admin@earnatural.com");
        //$email->setCC('kuriwaln@opallios.com');

        #$email->setTo('sales@ipgnaturalhealth-retail.com');
        $email->setFrom('support@earnatural.com', 'Earnatural Team');
		//$email->setSubject("Order Confirmation #".$postData['customer_id']); //
        $email->setSubject("Order/Inquiry @ Earnatural.com");
        $email->setMessage(view('templates/orderInternalMail', $data ));
        if (!$email->send()) 
		{
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }


	}

    
	function validateCard($vnumber)
	{
	    //require APPPATH.'Libraries/Luhn.php';
	    $luhn = new Luhn();
	    if ($luhn->validate(substr($vnumber, 0, -1), substr($vnumber, -1, 1)) == true) {
	        $vresult = "VALID";
	    } else {
	        $vresult = "INVALID";
	    }
	    echo json_encode(array('status' => $vresult));
	    
	}


    
}