<?php

namespace App\Controllers;
require __DIR__ . '/../../vendor/autoload.php';

use App\Models\Promocode as PromocodeModel;
use App\Controllers\BaseController;
use CodeIgniter\RESTful\ResourceController;

class Promocode extends ResourceController
{
    /**
	 * Return an array of resource objects, themselves in array format
	 *
	 * @return mixed
	 */
	public function index()
	{
		$model = new PromocodeModel();
      
        $data = $model->findAll();
      
        $response = [
            'status' => 200,
            'error' => null,
            'messages' => "Promocodes Found",
            "data" => $data,
        ];
        return $this->respond($response);
	}

	/**
	 * Return the properties of a resource object
	 *
	 * @return mixed
	 */
	public function show($id = null)
	{
		$model = new PromocodeModel();
      
        $data = $model->where(['id' => $id])->first();
      
        if ($data) {
            $response = [
                'status' => 200,
                'error' => null,
                'messages' => "Promocodes Found",
                "data" => $data,
            ];
            return $this->respond($response);
        } else {
            return $this->failNotFound('No Promocodes Found with id ' . $id);
        }
	}

	/**
	 * Return a new resource object, with default properties
	 *
	 * @return mixed
	 */
	public function new()
	{
		//
	}

	/**
	 * Create a new resource object, from "posted" parameters
	 *
	 * @return mixed
	 */
	public function create()
	{
		$model = new PromocodeModel();

        $data = [
            'product_name' => $this->request->getVar('product_name'),
            'promocode_title' => $this->request->getVar('promocode_title'),
            'promocode' => $this->request->getVar('promocode'),
            'promocode_discount' => $this->request->getVar('promocode_discount'),
            'promocode_type' => $this->request->getVar('promocode_type'),
            'status' => $this->request->getVar('status'),
            'start_date' => $this->request->getVar('start_date'),
            'expire_date' => $this->request->getVar('expire_date'),
            'created_by' => $this->request->getVar('created_by'),
            'updated_by' => $this->request->getVar('updated_by'),
        ];

        $model->insert($data);

        $response = [
            'status' => 200,
            'error' => null,
            'messages' => "Promocodes Saved",
        ];
      
        return $this->respondCreated($response);
	}

	/**
	 * Return the editable properties of a resource object
	 *
	 * @return mixed
	 */
	public function edit($id = null)
	{
		//
	}

	/**
	 * Add or update a model resource, from "posted" properties
	 *
	 * @return mixed
	 */
	public function update($id = null)
	{
		$model = new PromocodeModel();

        $data = [
            'name' => $this->request->getVar('name'),
            'email' => $this->request->getVar('email'),
            'mobile' => $this->request->getVar('mobile'),
        ];

        $model->update($id, $data);

        $response = [
            'status' => 200,
            'error' => null,
            'messages' => "Data Updated"
        ];
        return $this->respond($response);
	}

	/**
	 * Delete the designated resource object from the model
	 *
	 * @return mixed
	 */
	public function delete($id = null)
	{
		$model = new PromocodeModel();

        $data = $model->find($id);

        if ($data) {

            $model->delete($id);

            $response = [
                'status' => 200,
                'error' => null,
                'messages' => "Data Deleted",
            ];
            return $this->respondDeleted($response);
        } else {
            return $this->failNotFound('No Data Found with id ' . $id);
        }
	}
	
	
	/**
	 * Return the properties of a resource object
	 *
	 * @return mixed
	 */
	public function summary($id = null)
	{
		$model = new PromocodeModel();
      
        $data = $model->where(['created_at <=' => date('Y-m-d')]);
      
        if ($data) {
            $response = [
                'status' => 200,
                'error' => null,
                'messages' => "Promocodes Found",
                "data" => array(
					'active' => count($model->where(['created_at <=' => date('Y-m-d')])->findAll()),
					'total' => count($model->findAll()),
					'expired' => count($model->where(['created_at >=' => date('Y-m-d')])->findAll())
				),
            ];
            return $this->respond($response);
        } else {
            return $this->failNotFound('No Promocodes Found with id ' . $id);
        }
	}


}
