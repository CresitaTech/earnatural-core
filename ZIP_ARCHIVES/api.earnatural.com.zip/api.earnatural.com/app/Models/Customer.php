<?php
namespace App\Models;
use CodeIgniter\Model;

class Customer extends Model {

	protected $table      = 'customers';
    protected $primaryKey = 'id';
	protected $returnType     = 'array';

    protected $allowedFields = [
        'card_holder_name', 
        'phone_number', 
        'email', 
        'address_1',
        'address_2',
        'city',
        'state',
        'zip',
        'shipping_address_1',
        'shipping_address_2',
        'shipping_city',
        'shipping_state',
        'shipping_zip',
        'created_at'
    ];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


}
