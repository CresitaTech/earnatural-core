<?php
namespace App\Models;
use CodeIgniter\Model;

class Order extends Model {

	protected $table      = 'orders';
    protected $primaryKey = 'refId';
	
	protected $returnType     = 'array';

    protected $allowedFields = [
        'refId', 
        'accountNumber', 
        'accountType', 
        'authCode', 
        'avsResultCode',
        'cavvResultCode',
        'cvvResultCode',
        'refTransID',
        'responseCode',
        'transId',
        'saleId',
        'customerId',
        'status',
        'createdAt',
    ];

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


}