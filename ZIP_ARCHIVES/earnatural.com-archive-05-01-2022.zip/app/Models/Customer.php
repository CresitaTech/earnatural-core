<?php
namespace App\Models;
use CodeIgniter\Model;
use Michalsn\Uuid\UuidModel;

class Customer extends Model { #UuidModel

	protected $table      = 'customers';
    protected $primaryKey = 'id';
	protected $returnType     = 'array';

    protected $allowedFields = [
        'id',
        'card_holder_name', 
        'phone_number', 
        'email', 
        'address_1',
        'address_2',
        'city',
        'state',
        'zip',
        'promocode',
        'shipping_address_1',
        'shipping_address_2',
        'shipping_city',
        'shipping_state',
        'shipping_zip',
        'created_at'
    ];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


}
