
    <!--========== MAIN JS ==========-->


    <script src="<?=base_url('assets/js/main.js')?>"></script>

<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="<?=base_url('assets/js/jquery-3.3.1.slim.min.js')?>"></script>
    <!-- Popper.JS -->
    <script src="<?=base_url('assets/js/popper.min.js')?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>

<!--========== data table ==========-->
    <script>
            $(document).ready(function() {
        $('#example').DataTable();
    } );
        </script>
       <script src="<?=base_url('assets/datatable/jquery-3.5.1.js')?>"></script> 
       <script src="<?=base_url('assets/datatable/jquery.dataTables.min.js')?>"></script> 
       <script src="<?=base_url('assets/datatable/dataTables.bootstrap4.min.js')?>"></script> 


</body>

</html>